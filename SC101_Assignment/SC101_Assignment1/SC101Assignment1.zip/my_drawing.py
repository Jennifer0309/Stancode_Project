"""
File: 
Name:
----------------------
TODO:
"""

from campy.graphics.gobjects import GOval, GRect
from campy.graphics.gwindow import GWindow


def main():
    """
    TODO:
    """
    pass


if __name__ == '__main__':
    main()
